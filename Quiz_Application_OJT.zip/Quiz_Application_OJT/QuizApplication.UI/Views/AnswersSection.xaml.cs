﻿using System.Windows.Controls;

namespace QuizApplication.UI.Views
{
    /// <summary>
    /// Interaction logic for AnswersSection.xaml
    /// </summary>
    public partial class AnswersSection : UserControl
    {
        public AnswersSection()
        {
            InitializeComponent();
        }
    }
}
