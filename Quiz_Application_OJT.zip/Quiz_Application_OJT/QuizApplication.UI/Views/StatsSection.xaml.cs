﻿using System.Windows.Controls;

namespace QuizApplication.UI.Views
{
    /// <summary>
    /// Interaction logic for StatsSection.xaml
    /// </summary>
    public partial class StatsSection : UserControl
    {
        public StatsSection()
        {
            InitializeComponent();
        }
    }
}
